<?php include_once("templates/header.php"); ?>

<main class="home-main">
    <div class="container-fluid mt-5">
        <div class="container text-center">
            <?php if (isset($printMsg) && $printMsg != '') : ?>
                <p id="msg"><?= $printMsg ?></p>
            <?php endif; ?>
            <h1 id="main-title" class="fw-bold text-uppercase">Minha agenda</h1>
            <?php if (count($contacts) > 0) : ?>
                <div class="row">
                    <div class="col-lg-12">
                        <table class="table table-striped table-hover mt-4" id="contacts-table">
                            <thead class="table-dark">
                                <tr>
                                    <th scope="col-1">#</th>
                                    <th scope="col-2">Nome</th>
                                    <th scope="col-3">Telefone</th>
                                    <th scope="col-4">Rua</th>
                                    <th scope="col-5">Bairro</th>
                                    <th scope="col-6">Numero</th>
                                    <th scope="col-7">observação</th>
                                    <th scope="col-5">#</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($contacts as $contact) : ?>
                                    <tr>
                                        <td scope="row"><?= $contact["id"] ?></td>
                                        <td scope="row"><?= $contact["name"] ?></td>
                                        <td scope="row"><?= $contact["phone"] ?></td>
                                        <td scope="row"><?= $contact["street"] ?></td>
                                        <td scope="row"><?= $contact["neighborhood"] ?></td>
                                        <td scope="row"><?= $contact["number"] ?></td>
                                        <td scope="row"><?= $contact["observations"] ?></td>
                                        <td class="actions d-flex justify-content-end">
                                            <a href="<?= $BASE_URL ?>show.php?id=<?= $contact["id"] ?>"><img src="img/view.png"></a>
                                            <a href="<?= $BASE_URL ?>edit.php?id=<?= $contact["id"] ?>" class="ms-4"><img src="img/edit.png"></a>
                                            <form action="<?= $BASE_URL ?>/config/process.php" method="POST">
                                                <input type="hidden" name="type" value="delete">
                                                <input type="hidden" name="id" value="<?= $contact["id"] ?>">
                                                <button type="submit" class="btn-delete ms-4"><img src="img/delete.png"></button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            <?php else : ?>
                <p id="empty-list-text"> ainda n tem, <a href="<?= $BASE_URL ?>create.php">clique aqui</a></p>
            <?php endif; ?>
        </div>
    </div>
</main>

<?php include_once("templates/footer.php"); ?>
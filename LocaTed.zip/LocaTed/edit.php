<?php include_once("templates/header.php"); ?>

<div class="container-fluid mt-5">
    <div class="container">
        <?php include_once("backbtn.html"); ?>
        <h1 id="main-title">Editar contato</h1>
        <form action="<?= $BASE_URL ?>config/process.php" method="POST" id="create-form">
            <input type="hidden" name="type" value="edit">
            <input type="hidden" name="id" value="<?= $contact['id'] ?>">
            <div class="row">
                <div class="form-group col-6">
                    <label for="name">Nome do contato:</label>
                    <input type="text" class="form-control" name="name" id="name" placeholder="Nome" value="<?= $contact["name"] ?>" require>
                </div>
                <div class="form-group col-6">
                    <label for="phone">Telefone:</label>
                    <input type="text" class="form-control" name="phone" id="phone" placeholder="Telefone" value="<?= $contact["phone"] ?>" require>
                </div>
            </div>
            <div class="row">
                <div class="form-group col-4">
                    <label for="street">Rua:</label>
                    <input type="text" class="form-control" name="street" id="street" placeholder="Rua" value="<?= $contact["street"] ?>" require>
                </div>
                <div class="form-group col-4">
                    <label for="neighborhood">Bairro:</label>
                    <input type="text" class="form-control" name="neighborhood" id="neighborhood" placeholder="Bairro" value="<?= $contact["neighborhood"] ?>" require>
                </div>
                <div class="form-group col-4">
                <label for="number">Número:</label>
                <input type="text" class="form-control" name="number" id="number" placeholder="Número" value="<?= $contact["number"] ?>" require>
            </div>
            </div>
            <div class="form-group">
                <label for="observations" class="form-label">Obeservações:</label>
                <textarea class="form-control" id="observations" name="observations" rows="3" placeholder="Mensagem"><?= $contact["observations"] ?> </textarea>
            </div>
            <button type="submit" class="btn btn-primary mt-3">Atualizar</button>
    </div>
</div>
</div>
<?php include_once("templates/header.php"); ?>
<div class="container-fluid">
    <div class="container" id="view-contact-container">
        <?php include_once("backbtn.html"); ?>
        <h1 id="main-title" class="fw-bold text-uppercase"><?= $contact["name"] ?></h1>
        <p class="fw-bold">Telefone:</p>
        <p><?= $contact["phone"] ?></p>
        <p class="fw-bold">Rua:</p>
        <p><?= $contact["street"] ?></p>
        <p class="fw-bold">Bairro:</p>
        <p><?= $contact["neighborhood"] ?></p>
        <p class="fw-bold">Número:</p>
        <p><?= $contact["number"] ?></p>
        <p class="fw-bold">Oberservação:</p>
        <p><?= $contact["observations"] ?></p>
    </div>
</div>